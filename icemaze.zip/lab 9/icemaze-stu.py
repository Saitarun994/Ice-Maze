
import sys

from myGraph import *
from searchAlgo import *

def main():
    # <<<<<<<< Getting the file name >>>>>>>>
    filename = "test1.txt"     # !!!!!!!! change file name here or give cmd line inpute :) !!!!!!
    if len(sys.argv) > 1:
        filename = sys.argv[1]
    # <<<<<<<< End of user Input >>>>>>>>


    # <<<<<<<< Getting data from file >>>>>>>>
    file = open(filename, 'r')
    info = file.readline()
    infoList = info.split() # 1st line with lake data
    x = int(infoList[2])  # exit co-ordinate
    y = int(infoList[1]) - 1  # exit co-ordinate
    ending = str(x)+" "+str(y)
    lake = []
    line = file.readline()
    while line is not None:
        lake.append(line.split())
        line = file.readline()
        if not line:
            break
    # <<<<<<<< End of file read >>>>>>>>
    lakeGraph = Graph()
    i = 0
    j = 0

    '''
    Converting the matrix to a graph
    the grap is made up of legal moves within the lake
    so we only connect a node in the matrix from it's place
    to the edge or one cell before a rock
    '''
    for row in lake:
        j = 0
        for cell in row:
            cell_coordinate = str(i)+" "+str(j)  # Name of each cell in graph will be a coorodinate

            # <<<<<<<< START OF GRAPH ASSIGNMENT >>>>>

            if(lake[i][j]!="*"):

                if (i - 1 >= 0):  # up
                    k = i
                    while k >= 0:
                        if lake[k][j] == "*":
                            break
                        k -= 1
                    end_coord = str(k+1)+" "+str(j)
                    if cell_coordinate!= end_coord:
                        lakeGraph.addEdge(cell_coordinate, end_coord, 1)
                

                if (j - 1 >= 0): #left
                    k = j
                    while k >= 0:
                        if lake[i][k] == "*":
                            break
                        k -= 1
                    end_coord = str(i) + " " + str(k+1)
                    if cell_coordinate != end_coord:
                        lakeGraph.addEdge(cell_coordinate, end_coord, 1)
                   

                if (j + 1 < int(infoList[1])):  # right
                    k = j
                    while k < int(infoList[1]):
                        if lake[i][k] == "*":
                            break
                        k=k+1
                    end_coord = str(i) + " " + str(k-1)
                    if cell_coordinate != end_coord:
                        lakeGraph.addEdge(cell_coordinate, end_coord, 1)

                if (i + 1 < int(infoList[0])): # down
                    k=i

                    while k < int(infoList[0]):
                        if lake[k][j] == "*":
                            break
                        k= k+1
                    end_coord = str(k-1) + " " + str(j)
                    if cell_coordinate != end_coord:
                        lakeGraph.addEdge(cell_coordinate, end_coord, 1)

                # <<<<<<<< END OF GRAPH ASSIGNMENT >>>>>
            j = j+1
            #print(lakeGraph.getVertex(cell_coordinate))    #<<<< UNCOMMENT TO VIEW GRAPH >>>>
        print()
        i = i+1

    # <<<<<<<<< CALCULATING AND DISPLAYING COST >>>>>>>>>>>>>>
    r = dict()
    np = []
    i = 0
    j = 0
    for i in range(int(infoList[0])):
        j = 0
        for j in range(int(infoList[1])):
            start = str(i)+" "+str(j)
            if lake[i][j] != "*":
                print(lakeGraph.getVertex(start))
                if (lakeGraph.getVertex(start) is None or lakeGraph.getVertex(start) == []):
                    p = None
                    continue
                else:
                    p = findShortestPath(lakeGraph.getVertex(start), lakeGraph.getVertex(ending))
                # <<< adding to dictionary >>>
                if(start == ending):
                    if r[1] is None:
                        r[1] = []
                    r[1].append(start)
                    continue
                if p is not None:
                    if r.get(len(p)-1) is None:
                        r[len(p)-1]=[]
                    r[len(p)-1].append(start)
                # <<< end of dictionary add >>>
                else:   # creating empty list
                    np.append(start)
                #print([vertex.id for vertex in p])

    print("<<< Cost from start coordinate >>>")
    i=1
    while i <= len(r):
        print(i,": ",r[i])
        i=i+1

    print("<<< Coordinates with no start >>>")
    print(np)
    # <<<<<<<<<   END   OF  DISPLAYING COST   >>>>>>>>>>>>>>

if __name__ == "__main__":
    main()
