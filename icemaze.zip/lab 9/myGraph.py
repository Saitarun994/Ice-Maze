'''
defining the graph data structure here
'''

class vertex:
    __slots__ = "id", "connectedTo"

    def __init__(self, key):
        self.id = key
        self.connectedTo = {}

    def addNeighbor(self, nbr, weight=0):
        self.connectedTo[nbr] = weight

    def __str__(self):
        return str(self.id)+" connected To: " + str([str(x.id) for x in self.connectedTo])

    def getConnections(self):
        return self.connectedTo.keys()

    def getWeight(self, nbr):
        return self.connectedTo[nbr]

class Graph:

    __slots__ = 'vertList', 'numVertices'

    def __init__(self):
        self.vertList = {}
        self.numVertices = 0

    def addVertex(self, key):
        if self.getVertex(key) == None:
            self.numVertices += 1
            v = vertex(key)
            self.vertList[key] = v
        return v

    def getVertex(self, key):
        if key in self.vertList:
            return self.vertList[key]
        else:
            return None

    def __contains__(self, key):
        return key in self.vertList

    def addEdge(self, src, dest, cost=0):
        if src not in self.vertList:
            self.addVertex(src)
        if dest not in self.vertList:
            self.addVertex(dest)
        self.vertList[src].addNeighbor(self.vertList[dest], cost)

    def getVertices(self):
        return self.vertList.keys()

    def __iter__(self):
        return iter(self.vertList.values())